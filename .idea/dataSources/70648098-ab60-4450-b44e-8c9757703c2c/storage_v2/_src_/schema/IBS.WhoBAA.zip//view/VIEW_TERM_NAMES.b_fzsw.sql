create view VIEW_TERM_NAMES as
select rownum as Groups,
       decode(rownum, 
       1, 'свыше 10 лет', 
       2, 'от 7-ми до 10 лет', 
       3, 'от 5-ти до 7 лет',
       4, 'от 2-х до 5 лет',
       5, 'до 2-х лет') as Title
  from dual
connect by level <= 5
/


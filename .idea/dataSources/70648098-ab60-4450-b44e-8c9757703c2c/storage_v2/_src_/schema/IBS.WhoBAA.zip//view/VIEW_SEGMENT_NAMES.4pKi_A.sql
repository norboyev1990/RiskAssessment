create view VIEW_SEGMENT_NAMES as
select rownum as Groups,
       decode(rownum, 
       1, 'Инвест. проекты', 
       2, 'ЮЛ', 
       3, 'РБ') as Title
  from dual
connect by level <= 3
/


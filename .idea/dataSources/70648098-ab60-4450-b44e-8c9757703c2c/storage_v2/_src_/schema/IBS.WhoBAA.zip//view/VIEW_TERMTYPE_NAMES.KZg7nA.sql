create view VIEW_TERMTYPE_NAMES as
select rownum as Groups,
       decode(rownum, 
       1, 'Долгосрочные', 
       2, 'Краткосрочные') as Title
  from dual
connect by level <= 2
/


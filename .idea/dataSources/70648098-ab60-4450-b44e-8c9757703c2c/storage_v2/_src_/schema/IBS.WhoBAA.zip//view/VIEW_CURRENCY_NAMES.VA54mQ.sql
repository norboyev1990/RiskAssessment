create view VIEW_CURRENCY_NAMES as
select rownum as Groups,
       decode(rownum, 
       1, 'Национальная валюта', 
       2, 'Иностранная валюта') as Title
  from dual
connect by level <= 2
/


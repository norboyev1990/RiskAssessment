create TYPE REPORT1 AS OBJECT 
( /* TODO enter attribute and method declarations here */ 
  id NUMBER,
  Title VARCHAR2(255),
  Portfolio number,
  Partition number,
  NplBalans number,
  ToxBalans number,
  AmountNTK number,
  WeightNTK number,
  Reserve number,
  ReserveCover number 
  
);
/


create view VIEW_PERCENTAGE_NAMES as
select rownum as Groups,
       decode(rownum, 
       1, '0 - 5',
       2, '6 - 10',
       3, '11 - 15',
       4, '16 - 20', 
       5, '20 и более') as Title
  from dual
connect by level <= 5
/


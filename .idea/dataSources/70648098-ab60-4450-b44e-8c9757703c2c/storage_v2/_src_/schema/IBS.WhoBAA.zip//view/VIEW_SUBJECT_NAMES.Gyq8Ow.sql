create view VIEW_SUBJECT_NAMES as
select rownum as Groups,
       decode(rownum, 
       1, 'Юридический лица', 
       2, 'Индивид. предприятия', 
       3, 'Физический лица') as Title
  from dual
connect by level <= 3
/


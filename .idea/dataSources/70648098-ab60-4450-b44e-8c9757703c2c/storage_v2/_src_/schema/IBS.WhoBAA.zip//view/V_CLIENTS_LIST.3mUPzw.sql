create view V_CLIENTS_LIST as
SELECT 
            UNIQUE_CODE AS ClientID,
            MAX(NAME_CLIENT) AS ClientName,
            MAX(SUBJECT) AS ClientType,
            SUM(VSEGO_ZADOLJENNOST) AS TotalLoans,
            MAX(ADRESS_CLIENT) AS Address
        from credits
        WHERE REPORT_id =1 AND CLIENT_TYPE = 'J'
        GROUP BY UNIQUE_CODE
/

